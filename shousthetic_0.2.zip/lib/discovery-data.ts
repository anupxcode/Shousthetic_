export type Website = {
  slug: string
  name: string
  category: string
  description: string
  tags: string[]
  year: string
  url: string
  image: string
  tone: string
  number: string
}

export const websites: Website[] = [
  { slug: 'new-balance-990v6', name: 'New Balance 990v6', category: 'Everyday / Running', description: 'A modern classic balancing soft cushioning with considered, technical layers.', tags: ['Running', 'Mesh', 'Everyday'], year: '2025', url: 'https://www.newbalance.com/990/', image: '/shoes/trail-runner.png', tone: 'lime', number: '01' },
  { slug: 'nike-vomero-5', name: 'Nike Vomero 5', category: 'Retro runner / Running', description: 'An early-2000s runner reimagined with open mesh and a distinctly layered profile.', tags: ['Retro runner', 'Mesh', 'Streetwear'], year: '2025', url: 'https://www.nike.com/w/vomero-shoes-3n82yzy7ok', image: '/shoes/hero-runner.png', tone: 'violet', number: '02' },
  { slug: 'salomon-xt-6', name: 'Salomon XT-6', category: 'Trail / Technical', description: 'Trail-ready engineering, precise lines, and a silhouette that travels beyond the trail.', tags: ['Trail', 'Technical', 'Outdoor'], year: '2025', url: 'https://www.salomon.com/en-us/shop/sku/xt-6.html', image: '/shoes/trail-runner.png', tone: 'blue', number: '03' },
  { slug: 'dr-martens-adrian', name: 'Dr. Martens Adrian', category: 'Leather / Loafer', description: 'A substantial tassel loafer with polished leather and unmistakable attitude.', tags: ['Leather', 'Loafer', 'Craft'], year: '2025', url: 'https://www.drmartens.com/us/en/adrian-smooth-leather-tassel-loafers-black/p/22209001', image: '/shoes/leather-loafer.png', tone: 'orange', number: '04' },
  { slug: 'converse-chuck-70', name: 'Converse Chuck 70', category: 'Canvas / High Top', description: 'A familiar canvas high-top, elevated through texture, proportion, and enduring simplicity.', tags: ['Canvas', 'High top', 'Classic'], year: '2025', url: 'https://www.converse.com/shop/chuck-70', image: '/shoes/high-top.png', tone: 'gold', number: '05' },
  { slug: 'adidas-samba-og', name: 'adidas Samba OG', category: 'Court / Terrace', description: 'A low-profile terrace icon with clean leather lines and a warm gum sole.', tags: ['Court', 'Leather', 'Heritage'], year: '2025', url: 'https://www.adidas.com/us/samba', image: '/shoes/court-sneaker.png', tone: 'warm', number: '06' },
  { slug: 'asics-gel-kayano-14', name: 'ASICS GEL-KAYANO 14', category: 'Retro runner / Running', description: 'Reflective overlays and visible cushioning give this archival runner a new rhythm.', tags: ['Running', 'Silver', 'Y2K'], year: '2025', url: 'https://www.asics.com/us/en-us/gel-kayano-14/c/aa50105000/', image: '/shoes/hero-runner.png', tone: 'cosmic', number: '07' },
  { slug: 'clarks-wallabee', name: 'Clarks Originals Wallabee', category: 'Suede / Everyday', description: 'Soft suede, a natural crepe sole, and a shape that never needs to shout.', tags: ['Suede', 'Moccasin', 'Everyday'], year: '2025', url: 'https://www.clarks.com/en-us/wallabee/26155518-p', image: '/shoes/leather-loafer.png', tone: 'ocean', number: '08' },
]

export const categories = [
  { name: 'Everyday', number: '01', image: '/shoes/court-sneaker.png' },
  { name: 'Retro runners', number: '02', image: '/shoes/hero-runner.png' },
  { name: 'Trail', number: '03', image: '/shoes/trail-runner.png' },
  { name: 'Leather', number: '04', image: '/shoes/leather-loafer.png' },
  { name: 'High tops', number: '05', image: '/shoes/high-top.png' },
  { name: 'Court', number: '06', image: '/shoes/court-sneaker.png' },
  { name: 'Loafers', number: '07', image: '/shoes/hero-atelier.png' },
  { name: 'Technical', number: '08', image: '/shoes/trail-runner.png' },
  { name: 'Suede', number: '09', image: '/shoes/leather-loafer.png' },
  { name: 'Canvas', number: '10', image: '/shoes/high-top.png' },
]

export const collections = [
  { slug: 'quiet-classics', title: 'Quiet classics', subtitle: 'Good design that keeps its cool.', count: '12 pairs', image: '/shoes/court-sneaker.png', category: 'Everyday icons' },
  { slug: 'built-to-move', title: 'Built to move', subtitle: 'Technical shoes, considered closely.', count: '08 pairs', image: '/shoes/trail-runner.png', category: 'Performance' },
  { slug: 'leather-and-lace', title: 'Leather & lace', subtitle: 'A closer look at material and making.', count: '16 pairs', image: '/shoes/leather-loafer.png', category: 'Craft & material' },
  { slug: 'after-hours', title: 'After hours', subtitle: 'Everyday silhouettes with extra character.', count: '10 pairs', image: '/shoes/high-top.png', category: 'Personal style' },
]

export const photo = (id: string, width = 1200) => id.startsWith('/') ? id : `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${width}&q=85`
