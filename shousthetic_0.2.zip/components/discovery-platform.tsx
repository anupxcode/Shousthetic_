'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Bookmark, Check, Menu, Search, X } from 'lucide-react'
import { categories, collections, photo, websites, type Website } from '@/lib/discovery-data'

function getSaved(): string[] {
  if (typeof window === 'undefined') return []
  try { return JSON.parse(sessionStorage.getItem('shousthetic-saved') || '[]') } catch { return [] }
}

export function SiteHeader() {
  const path = usePathname()
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [compact, setCompact] = useState(false)
  useEffect(() => {
    const onScroll = () => setCompact(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })
    onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])
  const [query, setQuery] = useState('')
  const links = [['Discover', '/'], ['Explore shoes', '/explore'], ['Collections', '/collections'], ['About', '/about']]
  return (
    <header className={`site-header ${compact ? 'is-compact' : ''}`}>
      <Link href="/" className="wordmark" aria-label="Shousthetic home">SHOUSTHETIC<span>®</span></Link>
      <nav className="desktop-nav" aria-label="Main navigation">{links.map(([label, href]) => <Link key={href} href={href} className={path === href ? 'nav-link active' : 'nav-link'}>{label}</Link>)}</nav>
      <div className="header-actions">
        <button className="icon-button search-trigger" aria-label="Search shoes" onClick={() => setSearchOpen(!searchOpen)}><Search size={17} /></button>
        <Link href="/saved" className="icon-button saved-trigger" aria-label="Saved shoes"><Bookmark size={17} /></Link>
        <Link href="/submit" className="submit-link">Submit a shoe <span>+</span></Link>
        <button className="icon-button mobile-toggle" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={19} /> : <Menu size={19} />}</button>
      </div>
      {searchOpen && <form className="search-panel" onSubmit={(e) => { e.preventDefault(); window.location.href = `/explore?q=${encodeURIComponent(query)}` }}><Search size={17} /><input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search shoes…" aria-label="Search shoes" /><button type="submit" aria-label="Submit search"><ArrowRight size={17} /></button><button type="button" aria-label="Close search" onClick={() => setSearchOpen(false)}><X size={17} /></button></form>}
      {menuOpen && <nav className="mobile-menu" aria-label="Mobile navigation">{links.map(([label, href], i) => <Link onClick={() => setMenuOpen(false)} key={href} href={href}><span>0{i + 1}</span>{label}<ArrowUpRight size={18} /></Link>)}<Link href="/saved" onClick={() => setMenuOpen(false)}><span>05</span>Saved shoes<Bookmark size={17} /></Link><Link href="/submit" onClick={() => setMenuOpen(false)}><span>06</span>Submit a shoe<ArrowUpRight size={18} /></Link></nav>}
    </header>
  )
}

export function SiteFooter() {
  return <footer className="site-footer"><div className="footer-top"><Link href="/" className="wordmark">SHOUSTHETIC<span>®</span></Link><p>Good shoes, curated by taste.</p><a className="back-top" href="#top">Back to top <ArrowUpRight size={15} /></a></div><div className="footer-bottom"><span>© 2025 SHOUSTHETIC® — AN INDEPENDENT SHOE ARCHIVE</span><span>GOOD DESIGN. GREAT SHOES.</span><div><Link href="/about">About</Link><Link href="/submit">Submit a shoe</Link></div></div></footer>
}

export function SaveButton({ slug, compact = false }: { slug: string; compact?: boolean }) {
  const [saved, setSaved] = useState(false)
  useEffect(() => { setSaved(getSaved().includes(slug)) }, [slug])
  function toggle(e: React.MouseEvent) {
    e.preventDefault(); e.stopPropagation()
    const next = getSaved()
    const updated = saved ? next.filter((item) => item !== slug) : [...next, slug]
    sessionStorage.setItem('shousthetic-saved', JSON.stringify(updated))
    setSaved(!saved)
    window.dispatchEvent(new Event('saved-changed'))
  }
  return <button className={`save-button ${saved ? 'is-saved' : ''} ${compact ? 'compact' : ''}`} onClick={toggle} aria-label={saved ? 'Remove from saved shoes' : 'Save shoe'} aria-pressed={saved}>{saved ? <Check size={15} /> : <Bookmark size={15} />}{!compact && <span>{saved ? 'Saved' : 'Save'}</span>}</button>
}

export function ProjectCard({ site, index = 0 }: { site: Website; index?: number }) {
  return <article className={`project-card project-${index % 4}`}><Link href={`/website/${site.slug}`} className={`project-image tone-${site.tone}`}><img src={photo(site.image, 1100)} alt={`${site.name} shoe editorial photograph`} loading={index > 1 ? 'lazy' : 'eager'} /><span className="image-index">{site.number} / 08</span><span className="image-visit"><ArrowUpRight size={17} /></span><span className="image-caption">A STUDY IN {site.tags[0].toUpperCase()}</span></Link><div className="project-meta"><div><Link className="project-title" href={`/website/${site.slug}`}>{site.name}</Link><p>{site.category}</p></div><SaveButton slug={site.slug} compact /></div><p className="project-description">{site.description}</p><div className="project-tags">{site.tags.map((tag) => <span key={tag}>{tag}</span>)}<span className="project-year">{site.year}</span></div></article>
}

function Eyebrow({ children }: { children: React.ReactNode }) { return <div className="eyebrow"><span className="eyebrow-dot" />{children}</div> }

export function HomePage() {
  return <main id="top"><section className="hero"><div className="hero-copy"><Eyebrow>AN INDEPENDENT SHOE ARCHIVE — 001</Eyebrow><h1>A better eye<br />for <em>good shoes.</em></h1><p className="hero-deck">Discover thoughtfully designed sneakers, everyday icons, and footwear worth a closer look. A living collection for people who love shoes.</p><div className="hero-ctas"><Link href="/explore" className="button-lime">Explore the shoes <ArrowUpRight size={17} /></Link><Link href="/submit" className="text-link">Submit a shoe <span>↗</span></Link></div><div className="hero-index"><span>01 — Everyday icons</span><span>02 — Retro runners</span><span>03 — Trail ready</span><span>04 — Leather classics</span></div></div><div className="hero-art"><div className="hero-orb" /><div className="hero-art-label"><span>THE SHOE ARCHIVE</span><span>EST. MMXXV</span></div><div className="hero-frame frame-back"><img src={photo('/shoes/hero-runner.png', 750)} alt="Sculptural lime-accented technical running shoe" /><div className="frame-overlay"><span>03 / TECHNICAL</span><span>TRAIL — 2025</span></div></div><div className="hero-frame frame-front"><img src={photo('/shoes/hero-atelier.png', 700)} alt="Polished black leather shoes in a dark studio" /><div className="frame-overlay"><span>07 / LEATHER</span><span>CLASSICS — 2025</span></div></div><div className="hero-stamp"><span>CURATED<br />WITH<br /><i>feeling.</i></span></div><div className="hero-scroll"><ArrowDown size={14} /><span>SCROLL TO DISCOVER</span></div></div></section>
    <section className="ticker" aria-label="Good shoes, curated by taste"><div className="ticker-track">{Array.from({ length: 4 }, (_, i) => <span key={i}>GOOD SHOES, CONSIDERED CLOSELY <b>✳</b> A GOOD PAIR GOES A LONG WAY <b>✳</b></span>)}</div></section>
    <section className="featured section-pad"><div className="section-heading"><div><Eyebrow>01 / THE SHOE EDIT</Eyebrow><h2>Good shoes,<br /><em>well chosen.</em></h2></div><div className="section-aside"><p>Not more. Just better. A hand-picked collection of footwear worth your attention.</p><Link href="/explore" className="round-link" aria-label="Explore all shoes"><ArrowUpRight size={20} /></Link></div></div><div className="project-grid">{websites.slice(0, 6).map((site, i) => <ProjectCard key={site.slug} site={site} index={i} />)}</div><div className="center-link"><Link href="/explore" className="text-link">Explore all 08 pairs <ArrowRight size={15} /></Link></div></section>
    <section className="aesthetics section-pad"><div className="section-heading"><div><Eyebrow>02 / FIND YOUR FIT</Eyebrow><h2>What are you<br /><em>looking for?</em></h2></div><p className="aesthetic-intro">From court classics to trail-ready tech. Start anywhere.</p></div><div className="aesthetic-grid">{categories.map((category, i) => <Link key={category.name} href={`/explore?category=${encodeURIComponent(category.name)}`} className={`aesthetic-card aesthetic-${i}`}><img src={photo(category.image, 700)} alt="" loading="lazy" /><span className="aesthetic-number">{category.number}</span><span className="aesthetic-name">{category.name}<ArrowUpRight size={17} /></span></Link>)}</div><Link href="/explore" className="text-link all-aesthetics">All shoe styles <ArrowRight size={15} /></Link></section>
    <section className="manifesto"><div className="manifesto-mark">S<span>®</span></div><Eyebrow>A NOTE ON TASTE</Eyebrow><p>Less noise.<br />More <em>feeling.</em></p><div className="manifesto-foot"><span>QUIET CONFIDENCE.<br />GREAT SHOES.</span><Link href="/about" className="text-link">What we believe <ArrowUpRight size={15} /></Link></div></section>
    <section className="collections section-pad"><div className="section-heading"><div><Eyebrow>03 / THOUGHTFULLY GATHERED</Eyebrow><h2>Good shoes,<br /><em>in company.</em></h2></div><Link href="/collections" className="text-link">See all collections <ArrowRight size={15} /></Link></div><div className="collection-grid">{collections.slice(0, 3).map((item, i) => <Link key={item.slug} href={`/collections/${item.slug}`} className={`collection-card collection-${i}`}><div className="collection-image"><img src={photo(item.image, 950)} alt="" loading="lazy" /><span>{item.count}</span><ArrowUpRight size={18} /></div><div className="collection-meta"><span>{item.category}</span><h3>{item.title}</h3><p>{item.subtitle}</p></div></Link>)}</div></section>
    <section className="submit-cta"><div><Eyebrow>HAVE A GOOD PAIR?</Eyebrow><h2>Found shoes<br /><em>worth a second look?</em></h2></div><Link href="/submit" className="button-lime">Put it on our radar <ArrowUpRight size={17} /></Link><span className="cta-spark">✳</span></section></main>
}

export function ExplorePage() {
  const [filter, setFilter] = useState('All shoes')
  const [search, setSearch] = useState('')
  const filters = ['All shoes', 'Everyday', 'Retro runners', 'Trail', 'Leather', 'High tops', 'Court', 'Loafers', 'Technical', 'Suede', 'Canvas']
  const found = websites.filter((site) => {
    const style = `${site.category} ${site.tags.join(' ')}`.toLowerCase()
    const selectedStyle = filter.toLowerCase().replace(/s$/, '')
    return (filter === 'All shoes' || style.includes(selectedStyle)) && `${site.name} ${site.description} ${site.tags.join(' ')}`.toLowerCase().includes(search.toLowerCase())
  })
  useEffect(() => { const params = new URLSearchParams(window.location.search); const category = params.get('category'); const q = params.get('q'); if (category) setFilter(category); if (q) setSearch(q) }, [])
  return <main id="top" className="page-main"><section className="page-intro"><Eyebrow>THE SHOE INDEX / VOL. 001</Eyebrow><h1>Find your<br /><em>next favorite.</em></h1><p>A considered archive of sneakers, classics, and footwear with a point of view. Browse slowly, find your pair.</p><div className="intro-coordinate">51°30′26.4″N<br />000°07′39.6″W</div></section><section className="explore-content"><div className="filter-row"><div className="filter-pills" role="group" aria-label="Filter shoes">{filters.map((item) => <button key={item} onClick={() => setFilter(item)} className={filter === item ? 'filter-pill selected' : 'filter-pill'}>{item}</button>)}</div><label className="explore-search"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find a shoe…" aria-label="Search shoe styles" /></label></div><p className="result-count">SHOWING {String(found.length).padStart(2, '0')} OF 08 SHOES <span>· CURATED, NEVER RANKED</span></p><div className="project-grid explore-grid">{found.map((site, i) => <ProjectCard key={site.slug} site={site} index={i} />)}</div>{found.length === 0 && <div className="empty-state"><span>NO PAIRS FOUND. YET.</span><p>Nothing in the shoe archive matches just yet. Try another search.</p><button className="text-link" onClick={() => { setSearch(''); setFilter('All shoes') }}>Reset the shoe archive <ArrowRight size={15} /></button></div>}</section></main>
}

export function WebsiteDetail({ slug }: { slug: string }) {
  const site = websites.find((entry) => entry.slug === slug)
  if (!site) return <NotFoundPage />
  const related = websites.filter((entry) => entry.slug !== slug && entry.category.split(' / ')[0] === site.category.split(' / ')[0]).concat(websites.filter((entry) => entry.slug !== slug && entry.category.split(' / ')[0] !== site.category.split(' / ')[0])).slice(0, 3)
  return <main id="top" className="detail-page"><div className="detail-breadcrumb"><Link href="/explore"><ArrowLeft size={15} /> THE ARCHIVE</Link><span>{site.number} / 08</span></div><section className="detail-intro"><div><Eyebrow>{site.category.toUpperCase()} — {site.year}</Eyebrow><h1>{site.name}<span className="detail-period">.</span></h1><p>{site.description}</p></div><div className="detail-actions"><SaveButton slug={site.slug} /><a href={site.url} target="_blank" rel="noreferrer" className="button-lime">Visit the brand <ArrowUpRight size={16} /></a></div></section><div className={`detail-hero tone-${site.tone}`}><img src={photo(site.image, 1900)} alt={`${site.name} featured visual`} /><span>AN INDEPENDENTLY CURATED REFERENCE — NOT AFFILIATED</span></div><div className="detail-story"><div className="detail-label">A CLOSER LOOK</div><div><h2>Footwear<br /><em>with intention.</em></h2><p>{site.description} We saved this pair for its thoughtful proportions, material choices, and the way every detail feels like it belongs. An invitation to look closer, and to keep looking.</p><div className="project-tags">{site.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></div><aside><span>THE DETAILS</span><p>Category <b>{site.category}</b></p><p>Added <b>{site.year}</b></p><p>Source <b>Independent reference</b></p></aside></div><section className="related section-pad"><div className="section-heading"><div><Eyebrow>KEEP LOOKING</Eyebrow><h2>More shoes to <em>discover.</em></h2></div><Link href="/explore" className="text-link">Full archive <ArrowRight size={15} /></Link></div><div className="project-grid">{related.map((entry, i) => <ProjectCard key={entry.slug} site={entry} index={i} />)}</div></section></main>
}

export function CollectionsPage() {
  return <main id="top" className="page-main"><section className="page-intro"><Eyebrow>THE SHELF / VOL. 001</Eyebrow><h1>Good shoes,<br /><em>in company.</em></h1><p>Small, considered collections for whatever you want to wear next.</p></section><section className="all-collections section-pad"><div className="collection-grid">{collections.map((item, i) => <Link key={item.slug} href={`/collections/${item.slug}`} className={`collection-card collection-${i}`}><div className="collection-image"><img src={photo(item.image, 1050)} alt="" /><span>{item.count}</span><ArrowUpRight size={18} /></div><div className="collection-meta"><span>{item.category}</span><h3>{item.title}</h3><p>{item.subtitle}</p></div></Link>)}</div></section><div className="collection-note"><span>01 — A LIVING ARCHIVE</span><p>Every collection is assembled by hand, for no reason other than the feeling it leaves behind.</p></div></main>
}

export function CollectionDetail({ slug }: { slug: string }) {
  const item = collections.find((entry) => entry.slug === slug)
  if (!item) return <NotFoundPage />
  const featured = slug === 'built-to-move' ? websites.filter((s) => s.tags.some((t) => t === 'Running' || t === 'Trail' || t === 'Technical')) : slug === 'leather-and-lace' ? websites.filter((s) => s.tags.some((t) => t === 'Leather' || t === 'Suede' || t === 'Craft')) : slug === 'after-hours' ? websites.filter((s) => s.tags.some((t) => t === 'Streetwear' || t === 'High top' || t === 'Y2K')) : slug === 'quiet-classics' ? websites.filter((s) => s.tags.some((t) => t === 'Everyday' || t === 'Heritage' || t === 'Classic')) : websites.slice(0, 4)
  return <main id="top" className="detail-page"><div className="detail-breadcrumb"><Link href="/collections"><ArrowLeft size={15} /> THE SHELF</Link><span>{item.count.toUpperCase()}</span></div><section className="page-intro collection-intro"><Eyebrow>{item.category.toUpperCase()} / A COLLECTION</Eyebrow><h1>{item.title}<span className="detail-period">.</span></h1><p>{item.subtitle} A handful of shoes that share a certain something.</p></section><div className="detail-hero collection-detail-image"><img src={photo(item.image, 1900)} alt={`${item.title} collection`} /><span>FOOTWEAR, CURATED WITH FEELING — SHOUSTHETIC®</span></div><section className="section-pad"><div className="section-heading"><div><Eyebrow>THE SHOE EDIT</Eyebrow><h2>Collected <em>here.</em></h2></div></div><div className="project-grid">{featured.map((site, i) => <ProjectCard key={site.slug} site={site} index={i} />)}</div></section></main>
}

export function SubmitPage() {
  const [submitted, setSubmitted] = useState(false)
  return <main id="top" className="submit-page"><div className="submit-layout"><section className="submit-copy"><Eyebrow>THE ARCHIVE IS OPEN</Eyebrow><h1>Know a good<br /><em>pair of shoes?</em></h1><p>We’re always looking for footwear that makes us pause. Share a shoe you love, tell us what caught your eye, and we’ll take a closer look.</p><div className="submit-note"><span>WHAT WE LOOK FOR</span><p>Distinctive silhouettes. Thoughtful materials. A clear point of view. No hype, no fees, no promises — just good shoes, noticed.</p></div></section><section className="submit-form-wrap">{submitted ? <div className="success-message"><span className="success-icon"><Check size={23} /></span><Eyebrow>ON OUR RADAR</Eyebrow><h2>Thanks for<br /><em>the shoe tip.</em></h2><p>Your shoe suggestion is noted for this session. We’ll take a closer look.</p><button className="text-link" onClick={() => setSubmitted(false)}>Share another <ArrowRight size={15} /></button></div> : <form className="submit-form" onSubmit={(e) => { e.preventDefault(); setSubmitted(true) }}><span className="form-index">01 — YOUR SHOE PICK</span><label htmlFor="site-name">Which shoe should we look up?<span>*</span></label><input id="site-name" name="name" required placeholder="Brand and shoe name" /><label htmlFor="site-url">Where can we find the shoe?<span>*</span></label><input id="site-url" name="url" required type="url" placeholder="https://" /><label htmlFor="site-note">What caught your eye?</label><textarea id="site-note" name="note" rows={4} placeholder="A silhouette, a material, or what makes this pair special…" /><label htmlFor="site-email">Your email <span className="optional-label">OPTIONAL</span></label><input id="site-email" name="email" type="email" placeholder="hello@you.com" /><button className="button-lime form-submit" type="submit">Send it our way <ArrowUpRight size={16} /></button><p className="form-disclaimer">A local demo form. Your shoe suggestion isn’t sent or stored.</p></form>}</section></div></main>
}

export function AboutPage() {
  return <main id="top" className="about-page"><section className="about-hero"><Eyebrow>A SMALL SHOE MANIFESTO</Eyebrow><h1>Less hype.<br />More <em>feeling.</em></h1><p>SHOUSTHETIC® is an independent archive of footwear that makes us look twice.</p><div className="about-orbit"><span>GOOD<br />THINGS<br /><i>live here.</i></span></div><span className="about-coordinate">A PLACE FOR THE VISUALLY CURIOUS<br />EST. MMXXV</span></section><section className="about-body"><div className="about-left"><Eyebrow>WHY THIS EXISTS</Eyebrow><span className="about-big-n">S<span>®</span></span></div><div className="about-text"><h2>There are a lot of shoes.<br />Your closet <em>isn’t.</em></h2><p>So many pairs are made every year. Some deserve a second look. SHOUSTHETIC® is a small, independent attempt to find them — footwear with a point of view, thoughtful materials, and details that stay with you after you’ve laced up.</p><p>There are no rankings here. No paid placements. Just an evolving archive, assembled with care and shared with anyone who likes looking closely.</p><Link href="/explore" className="button-lime">Explore the shoe archive <ArrowUpRight size={16} /></Link></div></section><section className="about-principles"><Eyebrow>OUR NORTH STARS</Eyebrow><div className="principle-grid">{[['01', 'Curiosity over clicks', 'A good pair is its own reward.'], ['02', 'Quality over quantity', 'Fewer pairs. A little more thought.'], ['03', 'Open by nature', 'Good shoes deserve to be seen.']].map(([n, t, d]) => <article key={n}><span>{n} /</span><h3>{t}</h3><p>{d}</p></article>)}</div></section><section className="about-end"><p>Have something<br />we should <em>see?</em></p><Link href="/submit" className="round-link" aria-label="Submit a shoe"><ArrowUpRight size={20} /></Link></section></main>
}

export function SavedPage() {
  const [saved, setSaved] = useState<string[]>([])
  useEffect(() => { setSaved(getSaved()); const update = () => setSaved(getSaved()); window.addEventListener('saved-changed', update); return () => window.removeEventListener('saved-changed', update) }, [])
  const finds = websites.filter((site) => saved.includes(site.slug))
  return <main id="top" className="page-main saved-page"><section className="page-intro"><Eyebrow>YOUR SHOE SHELF</Eyebrow><h1>Keep the pairs<br /><em>you love.</em></h1><p>A little shelf for the shoes you want to come back to. Saved for this session.</p></section><section className="saved-content">{finds.length ? <><p className="result-count">{String(finds.length).padStart(2, '0')} SAVED SHOES</p><div className="project-grid">{finds.map((site, i) => <ProjectCard key={site.slug} site={site} index={i} />)}</div></> : <div className="empty-state"><span>NO SHOES ON THE SHELF. YET.</span><p>When a pair catches your eye, save it here for later.</p><Link href="/explore" className="button-lime">Browse the shoes <ArrowRight size={16} /></Link></div>}</section></main>
}

export function NotFoundPage() { return <main className="not-found"><Eyebrow>404 / OFF THE MAP</Eyebrow><h1>This page<br /><em>isn’t here.</em></h1><Link href="/explore" className="button-lime">Back to the archive <ArrowLeft size={16} /></Link></main> }
