import { ExplorePage } from '@/components/discovery-platform'
export const metadata = { title: 'Explore shoes — SHOUSTHETIC®', description: 'Discover considered sneakers, trail shoes, leather classics, and everyday footwear.' }
export default function Page() { return <ExplorePage /> }
