import { SubmitPage } from '@/components/discovery-platform'
export const metadata = { title: 'Submit a shoe — SHOUSTHETIC®', description: 'Share a shoe worth adding to the SHOUSTHETIC® footwear archive.' }
export default function Page() { return <SubmitPage /> }
