import { HomePage } from '@/components/discovery-platform'
export default function Page() { return <HomePage /> }
