import { SavedPage } from '@/components/discovery-platform'
export const metadata = { title: 'Saved shoes — SHOUSTHETIC®', description: 'Your personal shelf of saved footwear.' }
export default function Page() { return <SavedPage /> }
