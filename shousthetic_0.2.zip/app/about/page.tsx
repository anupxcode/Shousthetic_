import { AboutPage } from '@/components/discovery-platform'
export const metadata = { title: 'About — SHOUSTHETIC®', description: 'An independent archive of shoes with a point of view, curated by taste.' }
export default function Page() { return <AboutPage /> }
