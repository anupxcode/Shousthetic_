import { CollectionsPage } from '@/components/discovery-platform'
export const metadata = { title: 'Shoe collections — SHOUSTHETIC®', description: 'Thoughtfully gathered footwear collections: everyday icons, trail shoes, leather classics, and more.' }
export default function Page() { return <CollectionsPage /> }
