import { CollectionDetail } from '@/components/discovery-platform'
import { collections } from '@/lib/discovery-data'
export function generateStaticParams() { return collections.map(({ slug }) => ({ slug })) }
export default async function Page({ params }: { params: Promise<{ slug: string }> }) { const { slug } = await params; return <CollectionDetail slug={slug} /> }
