import type { Metadata } from 'next'
import { WebsiteDetail } from '@/components/discovery-platform'
import { websites } from '@/lib/discovery-data'
export function generateStaticParams() { return websites.map(({ slug }) => ({ slug })) }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const site = websites.find((item) => item.slug === slug)
  return { title: site ? `${site.name} — SHOUSTHETIC®` : 'Not found — SHOUSTHETIC®', description: site?.description }
}
export default async function Page({ params }: { params: Promise<{ slug: string }> }) { const { slug } = await params; return <WebsiteDetail slug={slug} /> }
